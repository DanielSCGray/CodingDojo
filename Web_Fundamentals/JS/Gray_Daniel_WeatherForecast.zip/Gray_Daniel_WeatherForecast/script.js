function remove(id) {
    document.querySelector(id).remove()
}