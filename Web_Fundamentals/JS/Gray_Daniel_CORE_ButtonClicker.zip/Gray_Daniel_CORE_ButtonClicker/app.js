function logout(element) {
    element.innerText = 'Logout'
}