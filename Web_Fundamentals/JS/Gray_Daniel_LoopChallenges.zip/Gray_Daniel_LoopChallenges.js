// Print odds 1-20
for (let i = 1; i < 20; i+=2) {
    console.log(i)
}
// Decreasing Multiples of 3
for (let i = 99; i >= 0; i-=3) {
    console.log(i)
}
//Print the sequence
var arr = [4,2.5,1,-.5,-2,-3.5]
//Sigma
var sum = 0
for (i = 1; i < 101; i++) {
    sum += i
}
console.log(sum)
//Factorial
var product = 1
for (var i = 1; i < 13; i++) {
    product *= i
}
console.log(product)