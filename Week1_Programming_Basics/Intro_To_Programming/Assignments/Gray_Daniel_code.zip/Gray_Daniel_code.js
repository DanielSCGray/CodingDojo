// YOUR COMMENT HERE - var will store a number representing the amount of likes
var likeCount = 0;
// YOUR COMMENT HERE - increase the value of likeCount
function increaseLikes() {
    // YOUR COMMENT HERE - incrementing by one
    likeCount = likeCount + 1;
}