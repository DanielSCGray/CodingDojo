var age = 11
var height = 43

if (height > 42) {
    console.log("Get on that ride, kiddo!");
}
else {
    console.log("Sorry kiddo. Maybe next year.");
}

//Stretch 1
if (height >= 42 && age >= 10) {
    console.log("Get on that ride, kiddo!");
}
else {
    console.log("Sorry kiddo. Maybe next year.");
}

// Stretch 2 
if (height >= 42 || age >= 10) {
    console.log("Get on that ride, kiddo!");
}
else {
    console.log("Sorry kiddo. Maybe next year.");
}
