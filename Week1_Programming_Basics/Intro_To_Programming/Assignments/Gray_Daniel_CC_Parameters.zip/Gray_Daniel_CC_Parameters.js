function greet(name) {
    console.log('Good day ' + name + '!')
}
//lvl 2

function greet2(name, time) {
    console.log('Good day, ' + name + '. the time is: ' + time)
}

// lvl 3

function greet3(name, time) {
    if (name === 'Count Dooku') {
        console.log("I'm coming for you, Dooku!")
    }
    else {
        console.log('Good day, ' + name + '. the time is: ' + time)
    }
}