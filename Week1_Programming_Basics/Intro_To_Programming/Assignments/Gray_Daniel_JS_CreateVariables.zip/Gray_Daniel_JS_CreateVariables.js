var age = 11;
// age will be a number and must be greater than 10 to allow access
var height = 42
// height is also a number and must be >= 42 for access