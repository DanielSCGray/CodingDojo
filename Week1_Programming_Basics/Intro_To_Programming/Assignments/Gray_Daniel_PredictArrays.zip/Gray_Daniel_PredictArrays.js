var contactInfo = ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345];
console.log(contactInfo);
// Will print out ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345]

var produce = ["apples", "oranges"];
var frozen = ["broccoli", "ice cream"];
frozen.push("hashbrowns");
console.log(frozen);
// Will print ["broccoli", "ice cream", "hashbrowns"]

var movieLibrary = ["Bambi", "E.T.", "Toy Story"];
movieLibrary.push("Zorro");
movieLibrary[1] = "Beetlejuice";
console.log(movieLibrary);

// Will print ["Bambi", "Beetlejuice", "Toy Story", "Zorro"]