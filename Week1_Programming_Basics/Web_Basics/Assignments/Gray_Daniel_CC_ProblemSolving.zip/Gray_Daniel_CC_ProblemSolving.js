/*1 
Look for "I" statements, "You" statements or the absence of either to determine 1st, 2nd or 3rd person
*/

/*2
-Define criteria for each statement
-Save each as a variable
-make a counter for I's and You's
- create a loop to parse the text and increment each counter when the I/You atatement indicators are seen
-make a conditional to see which statement type is prevalent
- if I's, return 1st person, if You's return second. if neither, return third.
*/

/*3
I think it depends on the problem.
sometimes the ideal outcome seems obvious but the real best outcome is totally outside the box.
other times its easy to define the correct success condition, but difficult to determine the best path to get there.
the latter is more common, but the former should still be considered.
*/